@extends('layouts.admin')

@section('content')
    <div class="card">
        <div class="card-header">
            <h3>Daftar Mobil</h3>
        </div>
    </div>
@endsection